# shutil_which.py

import shutil

print(shutil.which('virtualenv'))
print(shutil.which('requests'))
print(shutil.which('no-such-program'))